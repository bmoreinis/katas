/* Variable and Alert Kata Answers */

/* COLOR */

/* No Prompt */
var color = "orange";
alert("My favorite color is "+color);

/* Prompt */
var color = prompt("What is your favorite color?"); 
alert("Your favorite color is "+color);

/* AGE */

/* No Prompt */
var age = 15;
var name = "Nashaly";
alert(name+" is "+age+" years old.");

/* Prompt */
var age = prompt("How old are you?");
var name = prompt("What is your name?");
alert(name +" is "+age+" years old.");

/* ICE CREAM */

/* No Prompt */
var flavor = "coffee"; // string
var scoops = 2; // number
alert("I want "+scoops+" scoops of "+flavor+" ice cream.");

/* Prompt */
var flavor = prompt("What is yoru favorite ice cream?"); 
var scoops = prompt("How many scoops do you want?"); 
alert("You want "+scoops+" scoops of "+flavor);

/* PET */

/* No Prompt */
var petType = "dog";
var petName = "Sylvie";
alert("My "+petType+" is named "+petName);

/* Prompt */
var petType = "What type of pet do you have?";
var petName = "What is the pet's name?";
alert("Your "+petType+" is named "+petName);