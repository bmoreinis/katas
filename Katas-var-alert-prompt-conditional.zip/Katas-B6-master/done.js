/* Var, Prompt and Alert Katas */

/* COLOR KATAS */

/* No Prompt */
// make a string variable for color, set to your fave
// alert "My favorite color is " color
var color = "orange";
alert("My favorite color is "+color);

/* Prompt */
// make a string variable for color, prompt user for it
// alert color " is a nice color!"

/* AGE KATAS */

/* No Prompt */
// make a number variable for age, set it equal to your age
// make a string variable for name, set it to your name
// alert name is age years old

/* Prompt */
// make a number variable for age, prompt user for it
// make a string variable for name, prompt user for it
// alert name is age years old

/* ICE CREAM KATAS */

/* No Prompt */

 

/* Prompt */
// make a variable for ice cream flavor, prompt user for it
// make a variable for scoops, prompt user for it
// alert "You want " scoops "scoops of " flavor

/* PET KATAS */

/* No Prompt */
// variable for a pet type 
// variable for a pet name
// alert my pet type  is named pet name

/* Prompt */
// make a variable for pet type, prompt user for it 
// make a variable for pet name, prompt user for it
// alert "You have a pet type named pet name 